<?php
phpinfo();
 
?>